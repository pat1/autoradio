#!/bin/sh

export PYTHONPATH=/home/autoradio/autoradio/
#django-admin.py syncdb

django-admin.py runserver --noreload  --settings=settings  8090

